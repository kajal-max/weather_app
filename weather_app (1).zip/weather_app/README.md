# Code Challenge Template
Steps- 

0. Create a Virtual Environment and then install the dependency using -

    
        pip install -r requirements.txt
   

1. Start the Database using 

        docker-compose up 

2. Make Migrations in Database 

        python manage.py makemigrations

        python manage.py migrate

3. Run Data Ingestion Script 

        python main.py 

4. Run Django Test Cases

        python manage.py test
    
5. Run Django Server 

        python manage.py runserver