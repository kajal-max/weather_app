""""
Data Ingestion:
Reading Text file from wx_data and yld_data directory
and ingesting in Postgres Database
"""

import csv
import glob
from datetime import datetime
import psycopg2
import psycopg2.extras

def data_ingest():
    """
        Ingesting Weather Data
    """
    folder_path = "wx_data"
    file_list = glob.glob(folder_path + "/*.txt")
    values = []

    for i in range(0, len(file_list)):
        with open(file_list[i], "r", encoding="utf8") as file:
            tsv_reader = csv.reader(file, delimiter="\t")
            for row in tsv_reader:
                row[0] = str(row[0])
                row[1] = int(row[1])
                row[2] = int(row[2])
                row[3] = int(row[3])
                row.append(file_list[i][8:18])
                values.append(row)
    return values


def data_ingest_yld():
    """
        Ingesting Yield Data
    """
    file_path = "yld_data/US_corn_grain_yield.txt"
    yld = []
    with open(file_path, "r", encoding="UTF8") as file:
        txt_reader = csv.reader(file, delimiter="\t")
        for row in txt_reader:
            row[0] = int(row[0])
            row[1] = int(row[1])
            yld.append(row)
    return yld


# Establishing the connection
conn = psycopg2.connect(
    database="postgres",
    user="postgres",
    password="postgres",
    host="127.0.0.1",
    port="5434",
)

# Setting auto commit false
conn.autocommit = True

# Creating a cursor object using the cursor() method
cursor = conn.cursor()

values = data_ingest()

print("weather insertion started at" + str(datetime.now()))
# executing the sql statement
try:
    psycopg2.extras.execute_batch(
        cursor,
        """INSERT INTO public.weatherapp_weather(
        "date", "MaxTemp", "MinTemp", "Precipitation", "StationID") VALUES(%s,%s,%s,%s,%s);""",
        values,
    )
except Exception as e:
    print("Data Already Exist in Weather Table ")
yld = data_ingest_yld()
print("yield insertion started at" + str(datetime.now()))
try:
    psycopg2.extras.execute_batch(
        cursor,
        """INSERT INTO public.weatherapp_yield(
        "Year", "HarvestedYield")
        VALUES (%s, %s);""",
        yld,
    )
except Exception as e:
    print("Data Already Exist in Yield Table ")

result_query = """
INSERT INTO public.weatherapp_result
    (date, "StationID", "AvgMaxTemp", "AvgMinTemp", "TotalAccPpt")
    SELECT substring(date,1,4) AS date , "StationID" ,AVG("MaxTemp") AS AvgMaxTemp ,
    AVG("MinTemp") AS AvgMinTemp , SUM("Precipitation") AS TotalAccPpt
	FROM (select * from public.weatherapp_weather WHERE 
    "MaxTemp"<>-9999 or "MinTemp"<>-9999 or "Precipitation"<>-9999) AS tt
	GROUP BY "StationID" ,substring(date,1,4)
"""
try:
    cursor.execute(result_query)
except Exception as e:
    print("Data Already Exist in Result Table ")
conn.commit()
print("Records inserted........ at " + str(datetime.now()))

# Closing the connection
conn.close()
