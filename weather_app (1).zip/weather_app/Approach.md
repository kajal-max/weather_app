# Approach
## Database

For Database I have used Postgresql using docker-compose.yml file 

To Start the DB, Run:

    docker-compose up

## For Table Creation:
Used Django ORM for creation of Weather,Yield,Result Table

To Create Table Run:
    
        python manage.py makemigrations

        python manage.py migrate

## For Data Ingestion

I have created main.py file which read files from wx_data and yld_data and insert all data in bulk 
in postgresql database

Run:

        python main.py

## For API 
I have Used Django Rest Framework for API creation
refer weatherapp/ directory 
    
Run in Root Directory 

        python manage.py runserver