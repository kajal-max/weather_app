from rest_framework.test import APITestCase
from django.urls import reverse
from rest_framework import status
# Create your tests here.

class WeatherTestCase(APITestCase):
    """
        Test Weather Endpoints
    """
    def test_get_weather(self):
        response = self.client.get(reverse("WeatherList"))
        self.assertEqual(response.status_code,status.HTTP_200_OK)
        self.assertEqual(len(response.data.get("results")),0)
        self.assertEqual(response.data["count"], 0)

class YieldTestCase(APITestCase):
    """
        Test Yield Endpoints
    """
    def test_get_yield(self):
        response = self.client.get(reverse("YieldList"))
        self.assertEqual(response.status_code,status.HTTP_200_OK)
        self.assertEqual(len(response.data.get("results")),0)
        self.assertEqual(response.data["count"], 0)

class ResultTestCase(APITestCase):
    """
        Test Result Endpoints
    """
    def test_get_result(self):
        response = self.client.get(reverse("ResultList"))
        self.assertEqual(response.status_code,status.HTTP_200_OK)
        self.assertEqual(len(response.data.get("results")),0)
        self.assertEqual(response.data["count"], 0)
        