from django.contrib import admin
from django.urls import path
from .views import *

urlpatterns = [
    path(r"weather/", WeatherList.as_view(),name="WeatherList"),
    path(r"yield/", YieldList.as_view(),name="YieldList"),
    path(r"weather/stats/", ResultList.as_view(),name="ResultList"),
]
