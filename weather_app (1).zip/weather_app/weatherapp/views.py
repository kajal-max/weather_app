from rest_framework import generics
from rest_framework.pagination import PageNumberPagination
from django_filters.rest_framework import DjangoFilterBackend
from .models import Weather, Yield, Result
from .serializers import WeatherSerializers, YieldSerializers, ResultSerializers


class WeatherList(generics.ListAPIView):
    queryset = Weather.objects.all()
    serializer_class = WeatherSerializers
    pagination_class = PageNumberPagination
    filter_backends = [DjangoFilterBackend]
    filterset_fields = ["date", "StationID"]


class YieldList(generics.ListAPIView):
    queryset = Yield.objects.all()
    serializer_class = YieldSerializers
    pagination_class = PageNumberPagination


class ResultList(generics.ListAPIView):
    queryset = Result.objects.all()
    serializer_class = ResultSerializers
    pagination_class = PageNumberPagination
