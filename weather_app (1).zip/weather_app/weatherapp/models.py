from django.db import models


class Weather(models.Model):
    date = models.CharField(max_length=20)
    MaxTemp = models.IntegerField()
    MinTemp = models.IntegerField()
    Precipitation = models.IntegerField()
    StationID = models.CharField(max_length=20)

    class Meta:
        unique_together = ("date", "StationID")

class Yield(models.Model):
    Year = models.CharField(max_length=10, primary_key=True)
    HarvestedYield = models.IntegerField()

class Result(models.Model):
    date = models.CharField(max_length=20)
    StationID = models.CharField(max_length=20)
    AvgMaxTemp = models.IntegerField()
    AvgMinTemp = models.IntegerField()
    TotalAccPpt = models.IntegerField()

